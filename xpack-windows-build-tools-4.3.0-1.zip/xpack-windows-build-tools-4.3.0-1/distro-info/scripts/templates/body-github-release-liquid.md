![Github Releases (by Release)](https://img.shields.io/github/downloads/xpack-dev-tools/windows-build-tools-xpack/v{{ RELEASE_VERSION }}/total.svg)

Version **{{ RELEASE_VERSION }}** is a maintenance release of the **xPack Windows Build Tools** package; it updates to the latest upstream Busybox.

Or (TODO: edit!):

Version **{{ RELEASE_VERSION }}** is a new release of the **xPack Windows Build Tools** package, following the make release.

[Continue reading »](TODO: edit, add URL!)

_At this moment the binaries are provided for tests only!_
